USE classicmodels;
DROP TRIGGER IF EXISTS before_insert_stock_check;
DELIMITER $$
CREATE TRIGGER before_insert_stock_check BEFORE INSERT ON orderdetails FOR EACH ROW 
BEGIN 
    DECLARE stock INT;
    SELECT quantityInStock INTO stock FROM products WHERE productCode = NEW.productCode;
    IF stock IS NULL OR stock = 0 THEN 
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ERROR: The product is not in stock';
    ELSEIF NEW.quantityOrdered > stock THEN 
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ERROR: Insufficient stock to fulfill the order';
    END IF; 
END$$
DELIMITER ;