USE classicmodels;
DROP FUNCTION IF EXISTS customer_summary;
DELIMITER $$
CREATE FUNCTION customer_summary(cust_number INT) 
RETURNS VARCHAR(255)
DETERMINISTIC
READS SQL DATA
BEGIN 
    DECLARE orders INT;
    DECLARE products INT;
    SELECT COUNT(DISTINCT orderNumber) INTO orders FROM orders WHERE customerNumber = cust_number;
    SELECT COUNT(DISTINCT od.productCode) INTO products 
    FROM orders o JOIN orderdetails od ON o.orderNumber = od.orderNumber 
    WHERE o.customerNumber = cust_number;
    IF orders = 0 THEN 
        RETURN 'No orders or products';
    ELSE 
        RETURN CONCAT(orders, ' order/s and ', products, ' product/s');
    END IF;
END$$
DELIMITER ;