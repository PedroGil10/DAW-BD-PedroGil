USE classicmodels;
DROP TRIGGER IF EXISTS before_insert_order_limit;
DELIMITER $$
CREATE TRIGGER before_insert_order_limit BEFORE INSERT ON orders FOR EACH ROW 
BEGIN 
    DECLARE active_orders INT;
    SELECT COUNT(*) INTO active_orders FROM orders WHERE customerNumber = NEW.customerNumber AND status IN ('In Process', 'On Hold', 'Shipped');
    IF active_orders >= 3 THEN 
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A customer cannot have more than 3 active orders'; 
    END IF; 
END$$
DELIMITER ;