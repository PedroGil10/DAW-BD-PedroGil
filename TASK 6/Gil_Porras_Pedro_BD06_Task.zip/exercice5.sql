USE classicmodels;
DROP PROCEDURE IF EXISTS customers_sales_report;
DELIMITER $$
CREATE PROCEDURE customers_sales_report(IN office_name VARCHAR(50), IN year_param INT, OUT report TEXT)
BEGIN 
    DECLARE done INT DEFAULT 0;
    DECLARE emp_name VARCHAR(100);
    DECLARE cust_name VARCHAR(50);
    DECLARE total DECIMAL(10,2);
    DECLARE has_data INT DEFAULT 0;
    DECLARE cur CURSOR FOR
        SELECT CONCAT(e.firstName,' ',e.lastName), c.customerName, SUM(od.quantityOrdered * od.priceEach)
        FROM employees e
        JOIN offices o ON e.officeCode = o.officeCode
        JOIN customers c ON e.employeeNumber = c.salesRepEmployeeNumber
        JOIN orders ord ON c.customerNumber = ord.customerNumber
        JOIN orderdetails od ON ord.orderNumber = od.orderNumber
        WHERE o.city = office_name AND YEAR(ord.orderDate) = year_param
        GROUP BY e.employeeNumber, c.customerNumber
        ORDER BY e.lastName, c.customerName;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    SET report = '';
    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO emp_name, cust_name, total;
        IF done THEN LEAVE read_loop; END IF;
        SET has_data = 1;
        SET report = CONCAT(report, 'Employee: ', emp_name, ' | Customer: ', cust_name, ' | Total Sales: ', total, '\n');
    END LOOP;
    CLOSE cur;
    IF has_data = 0 THEN
        SET report = CONCAT('No sales data available for office "', office_name, '" in year ', year_param, '.');
    END IF;
END$$
DELIMITER ;