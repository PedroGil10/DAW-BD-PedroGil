USE classicmodels;
DROP TRIGGER IF EXISTS before_insert_sales_manager;
DELIMITER $$
CREATE TRIGGER before_insert_sales_manager BEFORE INSERT ON employees FOR EACH ROW 
BEGIN 
    DECLARE manager_count INT;
    SELECT COUNT(*) INTO manager_count FROM employees WHERE officeCode = NEW.officeCode AND jobTitle = 'Sales Manager';
    IF NEW.jobTitle = 'Sales Manager' AND manager_count > 0 THEN 
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only one Sales Manager is allowed per office'; 
    END IF; 
END$$
DELIMITER ;