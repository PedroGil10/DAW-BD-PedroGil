USE classicmodels;
DROP PROCEDURE IF EXISTS delete_employee;
DELIMITER $$
CREATE PROCEDURE delete_employee(IN emp_number INT)
BEGIN 
    DECLARE sup INT;
    DECLARE exists_emp INT;
    SELECT COUNT(*) INTO exists_emp FROM employees WHERE employeeNumber = emp_number;
    IF exists_emp = 0 THEN 
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The employee does not exist'; 
    END IF;
    SELECT reportsTo INTO sup FROM employees WHERE employeeNumber = emp_number;
    IF sup IS NULL THEN 
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The employee is the President and cannot be deleted'; 
    END IF;
    UPDATE customers SET salesRepEmployeeNumber = sup WHERE salesRepEmployeeNumber = emp_number;
    UPDATE employees SET reportsTo = sup WHERE reportsTo = emp_number;
    DELETE FROM employees WHERE employeeNumber = emp_number;
    SELECT CONCAT('Employee ', emp_number, ' deleted successfully') AS Result;
END$$
DELIMITER ;